package exam_project;

import java.util.List;
import java.util.stream.Stream;

        /**
         * klase rusiuoja duomenis Streamuose
         * demonstruojama:
        *  Nr. 64 stream kiekvienam
        *  Nr. 67 Funkcine nuoroda Lambda technologijoje
        */
public class Streams extends Exam_project{
    /**
     * metodas surusiuoja ir isprintina mases srauta
     * @param mL mases listas
     */
    public void sortedMass(List<Double> mL){
        Stream.of(mL)
               .sorted()
                /**
                 * 67 funkcine nuoroda Lambda
                 */
               .forEach((I) -> System.out.format("surusiuota mase"+I+"\n"));
    }
    /**
     * metodas surusiuoja ir isprintina laiko srauta
     * @param tL laiko listas
     */
    public void sortedTime(List<Integer> tL){
        Stream.of(tL)
               .sorted()
               .forEach((I) -> System.out.format("surusiuots laikas"+I+"\n"));
    }
    /**
     * metodas surusiuoja ir isprintinas kruvio srauta
     * @param cL kruvio listas
     */
    public void sortedCharge(List<Double> cL){
        /*
        * 64 streame naudojamas forEach ciklas
        */
        Stream.of(cL)
               .sorted()
               .forEach((I) -> System.out.format("surusiuotas kruvis"+I+"\n"));
    }
}
