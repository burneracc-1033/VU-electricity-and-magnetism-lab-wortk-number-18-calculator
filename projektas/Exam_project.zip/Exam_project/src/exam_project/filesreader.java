package exam_project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.EmptyStackException;
import java.util.Scanner;

/**
 *  programos esme; duomenu nuskaitymas is failo, bei isvestis i faila.
 *  demonstruojama: nr. 72 I/O failu nuskaitymas/irasymas, nr. 43 Masyvas: primityviems duomenims
 *  Nr, 25 išimties situacijos: klasės ir poklasės
 */
public class filesreader extends Data_Collector {
    /**
     * na... nesaugomi, salia tai daroma su kitais masyvais, bet cia yra ir primityvus
     * technologija nr 43 duomenys saugomi masyve
     */
    public int[] t1 = new int[10];
    /**
     * saugomas(private) laiko masyvas
     */
    private Integer[] t= new Integer[10];
    
    /**
     * saugomas (public) mases masyvas
     */
    public Double[] m= new Double[10];
    /**
     * sagomas (public) kruvio masyvas
     */
    public Integer[] q= new Integer[10];
    /**
     * metodas bando is failo nuskaityti duomenis
     * @param n kiek eiluciu duomenu nuskaityti
     * @return null programa nieko negrazina, bet Double, nes abstraktus metodas taippat Double
     * @throws java.lang.Exception
     * demonstruojama nr. 25 Išimtinės situacijos: klasės
     */
        @Override
    public Double setData1(Integer n) throws Exception {
        /**
         * Nr, 72 failų nuskaitymas
         */
        try{
            try (Scanner datafile = new Scanner(new File("C:\\Users\\Adminstratorius\\Documents\\NetBeansProjects\\Exam_project\\duom.txt"))) {
                String line = datafile.nextLine();
                System.out.println(line);
                
                SUPAAAHCONSTRUCTAAAA supconst =new SUPAAAHCONSTRUCTAAAA();
                supconst.superis(n);
                for (Integer i = 1; i<=n; i++) {
                    m[i]= datafile.nextDouble();
                    t[i]= datafile.nextInt();
                    q[i]= datafile.nextInt();
                    this.m[i]=m[i];
                    this.t[i]=t[i];
                    this.q[i]=q[i];
                }             
            }
}
        /**
         * demonstruojama nr.4 catch dalis, jei nerastas failas, parasyti zinute kad failas nerastas.
         * demonstruojama nr. 25 Išimtinės situacijos: poklasės 
         */
catch (FileNotFoundException e){
    System.out.println("File Not Found");
    throw new EmptyStackException();
}
        return null;
    }
    /**
    *metodo tikslas, irasyti zinute i faila. demonstruojama nr. 72 irasymo dalis
    */
    public void outputtofile(){
    try {
        try (FileWriter outputas = new FileWriter("outputofailas.txt")) {
            outputas.write("rezultatai: isspausdinami konsoles isvestyje");
        }
    } catch (IOException e) {
      System.out.println("An error occurred.");
   }
    }  
    /**
     * su GETSET technologija grazinamas issaugotas laiko parametru masyvas
     * @param n kelintas masyvo narys turi buti grazinamas
     * @return grazinamas masyvo n'asis narys
     */
        public Integer gett(Integer n){
        return t[n];
    }
        /**
     * su GETSET technologija grazinamas issaugotas mases parametru masyvas
     * @param n kelintas masyvo narys turi buti grazinamas
     * @return grazinamas masyvo n'asis narys
     */
            public Double getm(Integer n){
        return m[n];
    }
/**
     * su GETSET technologija grazinamas issaugotas pratekejusio kruvio parametru masyvas
     * @param n kelintas masyvo narys turi buti grazinamas
     * @return grazinamas masyvo n'asis narys
     */
    public Integer getq(Integer n){
        return q[n];
    }
}
