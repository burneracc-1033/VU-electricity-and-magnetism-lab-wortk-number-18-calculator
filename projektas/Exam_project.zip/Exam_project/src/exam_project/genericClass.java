package exam_project;
/**
 * pademonstruojama generics technologija
 * Technologija Nr. 37 Daugybiniškumas (Generics): klasės sukūrimas ir pagal ją objektai
 * @author Adminstratorius
 * @param <T> reiskia kad si klase yra "generic",
 * t.y. T raide bus pakeista "main" programoje nurodytu tipu.
 */
public class genericClass <T>{
    /**
     * @param t generic parametras.
     * Sis metodas main programoje objekto pagalba 
     * naudojamas isprintinti du i'hardcode'intus 
     * duomenis is klases "Constants"
     */
    public void method(T t){
        System.out.println(t+"\n");
        
    }
}
