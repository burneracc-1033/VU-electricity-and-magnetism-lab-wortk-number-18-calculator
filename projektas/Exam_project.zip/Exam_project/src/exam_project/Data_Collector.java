package exam_project;
import java.util.Random;
/**  
 * nuo pavadinimo klase prarado savo prasme, dabar jos tikslas yra sukurti random duomenis ir per metoda juos grazinti.
 * demonstruojama: nr. 56 private teise; nr. 86 toString
 * @author Adminstratorius
 */

public class Data_Collector extends Data_gather {
/**
 * nr.56 privatus duomuo
 */
    private Random randomnum = new Random();
    /**
     * nr. 86 demonstruoja toString technologija
     */
    public String randomnum1 = randomnum.toString();
    /**
     * vieas metodas grazina privatu duomeni
     * @return randomnum grazinamas privatus duomuo
     */
    public Random getrand(){
        return randomnum;
    }
    /**
     * nr 30. perrasomas metodas
     */
    @Override
    public void randommethod(){
        
    }
}
