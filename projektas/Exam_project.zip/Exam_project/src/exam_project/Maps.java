package exam_project;

import java.util.HashMap;
import java.util.Map;

/**
 * klase duomenis perkelia i Map.
 * Demonstruojama:
 * Nr. 19 Poklase 
 * Nr. 84 Map
 *
 * Nr. 19 si klase yra poklase(extends Exam_project)
 */
public class Maps extends Exam_project{
    /**
     * Nr. 84 sukuriamas Map, kuriame jei reikia galima saugoti duomenis
     */
    Map<Integer, Double> tempmap = new HashMap<Integer, Double>();
    /**
     * metodas sukuria mases map
     * @return HMmass grazinamas mases map
     */
    public Map<Integer, Double> mapmass(){
        Map<Integer, Double> HMmass = new HashMap<Integer, Double>();
        return HMmass;
    }
    /**
     * metodas sukuria laiko map
     * @return HMtime grazinamas laiko map
     */
    public Map<Integer, Integer> maptime(){
        Map<Integer, Integer> HMtime = new HashMap<Integer, Integer>();
        return HMtime;
    }
    /**
     * metodas sukuria kruvio map
     * @return HMcharge grazinamas kruvio map
     */
    public Map<Integer, Integer> mapcharge(){
        Map<Integer, Integer> HMcharge = new HashMap<Integer, Integer>();
        
        return HMcharge;
    }
    /**
     * demonstruojama Nr. 84 duomenu issaugojimas i Map
     * sis metodas iveda duomenis i zemelapi
     * @param n ivedami duomenys i map
     */
    public void setTemp(Map<Integer, Double> n){
        this.tempmap=n;
    }
}
