package exam_project;
/**
 * Klase, skirta pademonstruoti technologijas:
 * Nr. 12 (Operatoriai this ir super),
 * Nr. 24 (Konstruktorius super su ir be argumentų)
 */
public class SUPAAAHCONSTRUCTAAAA extends Data_gather {
    /**
     *@param n - tuscias Integeris,
     * reikalingas tik tam, kad butu su kuo klaseje
     * igyvendinti kitas technologijas
     */
    Integer n =null; 
    /**
     * Nr. 12 super operatorius
     * @param n pademonstruoja Nr. 12 this;
     * @throws Exception
     */
   
    public void superis(Integer n) throws Exception{
    super.setData1(n);
    super.Datafound();
    this.n=n;
    }/**
    *Nr. 24 konstruktorius super be argumentu
    */
public SUPAAAHCONSTRUCTAAAA(){
       super();
   }
   /**
    *Nr.24 konstruktorius super be argumentu
     * @param n demonstraacijai reikalingas parametras
    */
   public SUPAAAHCONSTRUCTAAAA(Integer n){
       super(n);
   }
   /**
    * perrasomas abstraktus metodas
    */
   @Override
    public void randommethod(){
        
    }
}
