package exam_project;

import java.util.List;

/**
 * klase atlieka pagrindinius ksaiciavimus
 * klase pademonstruoja technologijas Nr. 1 (Bitines matematines operacijos), 
 * bei Nr. 58 (Teisės ir jų panaudojimas: protected)
 * sioje programoje vyksta pagrindinis duomenu apdorojimas:
 * is duomenu randamas vario elektrocheminis ekvivalentas, bei jo paklaida
 */
public class Formulas extends Exam_project{
    /**
     * Nr. 58 saugomas protected duomuo paklaida, tai yra duomenu rezultatu paklaida
     */
    protected Double paklaida = 0.0;
    /**
     * saugomas public duomuo elechtrochemicalEQ, tai yra vario elektrocheminis ekvivalentas
     */
    public Double electrochemicalEq = 0.0;
    /**
     * siame metode apskaiciuojamas vario elektrocheminis ekvivalentas.
     * @param A Vario atmone mase;
     * @param z Vario valentingumas;
     * @param NA avogadro skaicius;
     * @param qe elektrono kruvis.
     */
    public void setelectrochemicalEq(Double A, Double z, Double NA, Double qe){
        Double temp = A/(z*NA*qe);
        this.electrochemicalEq = temp;
        System.out.println("gautas koeficientas: " + electrochemicalEq);
    }/**
     * metodo tikslas. apskaiciuoti elektrocheminio ekvivalento paklaida
     * @param mase is listo skaitomos vario meginio mases;
     * @param kruvis elektrolizes metu pratekejes kruvis;
     * @param datasize bandymo "checkpoint'u" kieks, t.y. kiek duomenu buvo paimta
     * Nr. 1 (Bitines matematines operacijos)
     */
    public void setpaklaida(List<Double> mase, List<Double> kruvis,Integer datasize){
        Double deltamase1 = (mase.get(datasize-1)-mase.get(0))/1000; //nes g ->kg
        Double deltakruvis1 = kruvis.get(datasize-1)-kruvis.get(0);
        Double vidurkis = deltamase1/deltakruvis1;
        Double tarpineVerte1 = Math.pow(0.0-vidurkis, 2);
        Double tarpineVerte2 = 0.0;
        Integer i = 1;
        while(i < datasize){
        tarpineVerte1 += Math.pow((((mase.get(i)/1000)-(mase.get(i-1)/1000))/(kruvis.get(i)-kruvis.get(i-1)))-vidurkis, 2);
        i++;
    }
        tarpineVerte2 = tarpineVerte1/(datasize-1);
        this.paklaida = (Math.sqrt(tarpineVerte2))/2;
        System.out.println("gauta paklaida: "+paklaida);
    }
}
