
package exam_project;
import java.util.Scanner;
/**
 * klase is klaviaturos gaunama reikiamu duomenu kieki
 *demonstruojamos technologijos: nr. 8 (konstruktorius); nr. 10 duomuo.
 * klases tikslas: ekrane paklausti kiek duomenu tasku paimti is failo 
 * ir irasyti ivesta skaiciu
 */
public class data_amount extends Exam_project {
    /**
     * @param data_size - skirtas veliau nurodyt kiek duomenu eiluciu paimti is failo. 
     *  Nr. 10 Duomuo.
     */
    int data_size = 0;
    /**
     * klases sukonstravimo metu i ekrana isveda zinute ir gauna atsakyma is klaviaturos ivesties
     * Nr. 8 konstruktorius
     */
    public data_amount(){
        System.out.println("input the amount of data points requested");
        Scanner in = new Scanner(System.in);
        data_size = in.nextInt();
        this.data_size=data_size;
}
}
