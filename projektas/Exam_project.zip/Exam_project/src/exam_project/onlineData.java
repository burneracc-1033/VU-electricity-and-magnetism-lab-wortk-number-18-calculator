package exam_project;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
/**
 * klase is interneto nuskaito ir issaugo duomenis
 *technologijos:
 *  
 *  Nr. 73 I/O: nuskaitymas iš internetinės nuorodos
 *  Nr. 14 panaudojimas throws ir throw 
 *  nr. 4 (try, catch),
 *  
 */
public class onlineData extends Exam_project {
    /**
     * sukuriamas konstantu objektas(naudojamas ir pagrindineje programoje
     */
    Constants consts = new Constants();
        /**
         * 
         * nr. 14 panaudojamas throws 
         * @throws Exception isimtis su interneto nuorodomis
         * is interneto nuskaitomas ir issaugomas avogadoro skaicius
         */
    public void setNa() throws Exception{  
        /**
         *  nr. 4 (try),
         */
       try{ 
        URL url = new URL("https://physics.nist.gov/cuu/Constants/Table/allascii.txt");
        URLConnection con = url.openConnection();
        InputStream is =con.getInputStream(); 
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line = null;
        
        while ((line = br.readLine()) != null) {
            if (line.contains("Avogadro constant"))
            {  
                String str1 = line;
                String stripedValue = (str1.replaceAll("[\\s+a-zA-Z(-)^-^--- :]",""));
                Double dbl = Double.parseDouble(stripedValue);
                consts.setNa(dbl);
            }    
        }
        br.close();
    }/**
     *  nr. 4 (catch),
     */
   catch (MalformedURLException e) {
       
       System.out.println("URL is not working");
        throw new Exception(e);
        
    }
       /**
     *  nr. 4 (finally),
     */
    finally {
        System.out.println("Na collection complete");
    }
    }
    
      /**
       * pademonstruojama nr 73 nuskaitymas is internetines nuorodos
       * is interneto nuskaitomas ir issaugomas elektrono kruvis
       * @throws IOException isimtis del interneto nuorodu
       */
public void setqe() throws IOException, Exception{
    try{
        URL url = new URL("https://physics.nist.gov/cuu/Constants/Table/allascii.txt");
        URLConnection con = url.openConnection();
        InputStream is =con.getInputStream(); 
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line = null;
        
        while ((line = br.readLine()) != null) {
             if (line.contains("atomic unit of charge  "))
            {  
                String str1 = line;
                String stripedValue = (str1.replaceAll("[\\s+a-zA-Z(-)^-^--- :]",""));
                Double dbl1 = Double.parseDouble(stripedValue);
                consts.setEC(dbl1);
            }   
        }
        br.close();}
    catch (MalformedURLException e) {
       
       System.out.println("URL is not working");
       /**
        * nr. 14 throw
        */
        throw new Exception(e);
}}
/**
 * grazinamas avogadro skaicius is kitos klases objekto
 * @return consts.getNa() grazinamas avogadro skaicius
 */
    public Double getAvogadro(){
        return consts.getNa();
    }
    /**
     * grazinamas elektrono kruvis is kitos klases objekto
     * @return consts.EC() grazinamas elektrono kruvis
     */
    public Double getElC(){
        return consts.getEC();
    }
}
