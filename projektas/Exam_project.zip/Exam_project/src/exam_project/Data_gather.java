package exam_project;

/**
 * si abstrakti klase skirta rinkti duomenis
 * Demonstruojama: 
 * Nr. 13 išimties situacijos
 * Nr. 30 Abstrakti klasė ir abstraktus metodas
 * Nr.30 abstrakti klase
 */
public abstract class Data_gather extends Exam_project{
    /**
     * saugomasa duomuo data, kiek duomenu paimti is failo
     */
    public Data_gather(){
        
    }
    public Data_gather(Integer N){
        
    }
   
public Integer data = 0;
     /** 
     * sis metodas kvieciamas super pagalba
     * i ekrana isveda kad duomenis gauti
     */
    public void Datafound(){
        System.out.println("Data acquired");
    }/**
     * Nr. 30 abstraktus metodas
     */
    abstract void randommethod();
    /**
     * sis metodas kvieciamas super pagalba.
     * jis gauna ir issaugo gaunama duomenu kieki
     * demonstruojama Nr. 13 išimties situacijos
     * @param n gaunamas duomenu kiekis
     * @return null metodas nieko negrazina
     * @throws Exception
     */
    public Double setData1(Integer n) throws Exception{
     
       this.data=n;
       return null;
    }
;
}
