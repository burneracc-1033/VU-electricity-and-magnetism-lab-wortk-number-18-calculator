
package exam_project;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * klase issaugo duomenis Setuose
 * demonstruojama:
 * Nr. 70 Aiškinimo (Annotation) parametrų panaudojimas
 * Nr. 83 Set
 */
public class Sets extends Exam_project{
    /**
     * randset - laikinai saugomas setas(nenaudojamas)
     * pademonstruojamas Nr. 83 Set saugojimas
     */
     Set<Double> randset = new HashSet<Double>();
     /**
      * metodas laiko duomenis saugo sete
      * @param n Map parametras, paverciamas i seta
      * @return timeset grazinamas laiko setas
      */
     public Set<Integer> gettimeSet(Map<Integer, Integer> n){
        Set<Integer> timeset = new HashSet<Integer>(n.values());
        
        return timeset;
    }
     /**
      * metodas kruvio duomenis saugo sete
      * @param n Map parametras, paverciamas i seta
      * @return chargeset grazinamas kruvio setas
      */
     public Set<Integer> getchargeSet(Map<Integer, Integer> n){
        Set<Integer> chargeset = new HashSet<Integer>(n.values());
        
        return chargeset;
    }
     /**
      * metodas mases duomenis saugo sete
      * @param n Map parametras, paverciamas i seta
      * @return massset grazinamas mases setas
      */
     public Set<Double> getmassSet(Map<Integer, Double> n){
        Set<Double> massset = new HashSet<Double>(n.values());
        
        return massset;
    }
     /**
     * pademonstruojama nr. 70 annotations
     * @param n metodo parametras, laikinai saugomas setas
     * @deprecated nurodo, kad sis metodas daugiau nebebus naudojamas
     */
     @Deprecated
    public void setTemp(Set<Double> n){
        this.randset=n;
    }
}
