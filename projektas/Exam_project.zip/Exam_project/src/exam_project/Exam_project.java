/**
 * Projektas: "E3 laboratorinis darbas
 **/
package exam_project;
import java.util.*;
import java.util.stream.Collectors;
import java.io.IOException;

/**
 * objektu sasaja
 * Demonstruojama technologija Nr. 36 sasajos interface
 **/
interface step {
    int zyx= 5;
    /**
     * abstraktus metodas
     * @param z programos zingsnis
     */
    public void currentstep(Integer z);
}
/**
 * klase nusako, kuri zingsni atlieka programa
 * demonstruojama:
 * Nr. 6 Salygos
 * Nr. 29 Metodo perrašymas (overriding)
 **/
class mode implements step{
    /**
     * demonstruojama Nr. 29 Metodo perrasymas
     * perrasomas interface metodas, metodas nusako, kuriame zingsnije yra programa
     * @param n programos zingsnis
     */
    @Override
    public void currentstep(Integer n){
        switch (n){
            /**
             * demonstruojama Nr. 6 salygos(bet vietoj if else naudojami switchai)
             */
            case 1:
                System.out.println("\n acquiring online data \n");
                break;
            case 2:
                System.out.println("\n collecting data from experiment file \n");
                break;
            case 3:
                System.out.println("\n sorting collected data \n");
                break;
            case 4:
                System.out.println("\n calculating the results \n");
                break;
            case 5:
                System.out.println("\n end of program \n");
                break;
            
        }
    }
}
/**
 * pagrindine projekto klase
 * @author Mantvydas
 * demonstruojama:
 * Nr. 5 Ciklai
 * Nr. 7 Klase, objekto sukurimas
 * Nr. 11 metodo iskvietimas
 * nr. 25 isimtine situoacija klaseje
 * 
 * demonstruojama Nr. 7 klase  
 */
public class Exam_project {

    /**
     * konstantu saugojimo klase
     * demonstruojama:
     * Nr. 9 metodas klaseje
     * Nr. 50 Operatorius static: duomuo, metodas
     **/
    static class Constants{
        public Double CuAM = 0.06355;
        public Integer CuValence = 2;
        public Double CuVal = 2.0;
        /**
         * Nr. 50 saugomas static duomuo
         */
        static Double I =0.3;
        public Double avogadro= 0.0;
        public Double EC = 0.0;
        /**
         * metodas issaugo avogadro skaiciu ir paraso, jog ji issaugo, bei ji isprintina
         * @param N_avogadro parametras avogadro skaicius gaunamas is kitos klases
         * Demonstruojamas Nr. 9 Metodas klaseje
         */
        public void setNa(Double N_avogadro){
            N_avogadro*= Math.pow(10, 23);
            this.avogadro = N_avogadro;
            System.out.println("obtained avogadro constant: "+avogadro);
        }
        /**
         * metodas issaugo elektrono kruvi ir paraso, jog ji issaugo, bei ji isprintina
         * @param electronc is kitos klases gaunamas elektrono kruvio parametras
         */
        public void setEC(Double electronc){
            electronc*= Math.pow(10, -19);
            this.EC = electronc;
            System.out.println("obtained charge of an electron: "+EC);
        }
        /**
         * Nr. 50 statinis metodas
         */
        public static void loremIpsum(){
            System.out.println("this is static method");
        }
        /**
         * metodas grazina avogadro skaiciu
         * @return avogadro grazinamas avogadro skaicius 
         */
        public Double getNa(){
            return avogadro;
        }
        /**
         * metodas grazina elektrono kruvi
         * @return EC grazinamas elektrono kruvis 
         */
        public Double getEC(){
            return EC;
        }
        /**
         * metodas grazina Sroves stipri
         * @return I grazinamas sroves stipris 
         */
        public Double getI(){
            return I;
        }
        /**
         * metodas grazina vario atomine mase
         * @return CuAM grazinama vario atomine mase 
         */
        public Double getCuAM(){
            return CuAM;
        }
        /**
         * metodas grazina vario valentinguma
         * @return CuVal grazinamas vario valentingumas
         */
       public Double getCuVal(){
        return CuVal;
    }
    }
     /**
     * pagrindine programa
     * @param args pagrindines programos parametras
     * @throws IOException Demonstruojama Nr. 25 isimtine situacija klaseje
     */
    public static void main(String[] args) throws IOException, Exception {
        /**
         * Nr.15 Anoniminė įdėtinė klasė ir pagal ją objektai viduje klasės
         */
                Thread t = new Thread()
        {
            @Override/**
             * perrasomas paleidimo metodas, paleidimo pradzioja i ekrana isvedama, kad programa prasidejo
             */
            public void run()
            {
                System.out.println("program start");
            }
        };
                /**
                 * 36 Objektų derinimas pagal sąsajas
                 */
                mode rezimas = new mode();
               step zyx = rezimas;
        t.start();       
        
        rezimas.currentstep(1);
        /**
         * demonstruohjama Nr. 7 objekto sukurimas
         */
        onlineData web = new onlineData();
        /**
         * Demonstruojama Nr. 11 metodo iskvietimas
         */
        web.setNa();
        web.setqe();
        
        rezimas.currentstep(2);
        filesreader flr =new filesreader();
        /**
         * Nr. 30 panaudojamas anksciau buves abstraktus metodas
         */
       Data_Collector obj1 = new Data_Collector();
       obj1.randommethod();
       data_amount kiekis = new data_amount();
       Integer DataPoints = kiekis.data_size;
       
       flr.setData1(DataPoints);
       
       Maps map = new Maps();
       Map<Integer, Double> HMmass = map.mapmass();
       Map<Integer, Integer> HMtime = map.maptime();
       Map<Integer, Integer> HMcharge = map.mapcharge();
       
       /**
        * demonstruojama nr. 5 Ciklai
        */
       for(Integer i = 1; i<=DataPoints;i++){
       HMmass.put(i, flr.getm(i));
       HMtime.put(i, flr.gett(i));
       HMcharge.put(i, flr.getq(i));
       }
       
       
       Sets set=new Sets();
       Set<Double> masesset = set.getmassSet(HMmass);
       Set<Integer> laikoset = set.gettimeSet(HMtime);
       Set<Integer> kruvioset = set.getchargeSet(HMcharge);
       
       System.out.println("mass: "+masesset.toString());
       System.out.println("time: "+laikoset.toString());
       System.out.println("charge: "+kruvioset.toString());
       
       List<Double> maseslist = new ArrayList<Double>(HMmass.values());
       List<Integer> laikolist = new ArrayList<Integer>(HMtime.values());
       List<Integer> kruviolist = new ArrayList<Integer>(HMcharge.values());
       List<Double> kruviodblist = kruviolist.parallelStream().mapToDouble(i->i)
            .boxed().collect(Collectors.toList());
       /**
        * Nr. 37 panaudojamas generic objektas
        */
       genericClass printer = new genericClass();
       System.out.println("\n hardcoded constants: ");
       Constants consts = new Constants();
       printer.method(consts.CuValence);
       printer.method(consts.CuAM);
       
       
       rezimas.currentstep(3);
       Streams stream = new Streams();
       stream.sortedMass(maseslist);
       stream.sortedTime(laikolist);
       stream.sortedCharge(kruviodblist);
   
       rezimas.currentstep(4);
    Formulas form = new Formulas();
    
    form.setelectrochemicalEq(consts.getCuAM(), consts.getCuVal(), web.getAvogadro(), web.getElC());   
    form.setpaklaida(maseslist, kruviodblist, DataPoints);
    randomness rand = new randomness();
    System.out.println("\n kad pademonstruot jog technologijos panaudotos, RandomBulshitGo:"+rand.getrandskaic());
    rezimas.currentstep(5);
    
       }
    
    
    }