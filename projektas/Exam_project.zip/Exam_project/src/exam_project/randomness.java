package exam_project;
import java.util.Random;

/**
 * programos tikslas: pademonstruoti technologijas:
 * Nr. 20 (Viršklasės duomenų ir metodų panaudojimas);
 * Nr. (59 Teisės ir jų panaudojimas: public)
 * programa sukuria du duomenis
 */
public class randomness extends Data_Collector{
    /**
     * 
     * demonstruojama Nr. 20 Viršklasės duomenų ir metodų panaudojimas
     * Nr. 59 - public duomuo
     */
    public Random randskaic = getrand();
    /**
     * saugomas duomuo randskaic, tai jokios svarbios funkcijos neturintis duomuo,
     * tačiau jo vertė yra nuoroda į viršklasės elementą
     */
    public String randskaic1 = randomnum1;
    /**
     * Nr. 59 public metodas grazinantis duomeni
     * @return randskaic grazina duomeni randskaic
     */        
    public String getrandskaic(){
        
        return randskaic.toString();
    }
}
