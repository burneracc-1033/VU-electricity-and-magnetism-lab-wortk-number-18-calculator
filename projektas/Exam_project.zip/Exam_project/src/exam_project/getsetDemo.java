package exam_project;
/**
 * Klase skirta pademonstruoti nuorodos priskyrima ir GETSET technologijas:
 * Nr. 3 nuorodos priskyrimas;
 * Nr. 69(nice) GETSET technologija
 **/
public class getsetDemo extends Exam_project {
    /**
     * @param tempInt1 parametras reikalingas 3 technologijai;
     * @param tempInt pademonstruoja Nr. 3 technologija  
     */
   Integer tempInt1 = 2;
   Integer tempInt = tempInt1;
   
   /**
    * Nr.69 Set technologijos dalis:
    * @param NablaXB0 - metodo parametras, pakeiciantis
    * tempInt verte
    */
   public void setTempInt(Integer NablaXB0){
       this.tempInt = NablaXB0;
   }
   /**
    * Nr. 69 Get dalis
    * @return tempint grazina tempInt verte
    */
   public Integer getTempInt(){
       return tempInt;
   }
}
